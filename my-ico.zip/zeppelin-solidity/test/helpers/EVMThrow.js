export default 'invalid opcode';
